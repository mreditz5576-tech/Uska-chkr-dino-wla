"""
Eagle — SQLite Database Layer (replaces MongoDB)
Auto-creates razor_x.db on first init_db() call. Zero external setup.
All functions keep the same signatures as the old Mongo version.
"""
import os
import json
import secrets
import asyncio
import string as _string
import datetime
import aiosqlite

# ============ CONSTANTS ============
PAID_PLANS = ["Starter", "Pro", "Elite", "Legend", "Custom"]
MAX_KEYS_PER_GENERATE = 50
KEY_PREFIX = "Eagle-"
KEY_UNUSED_TTL_HOURS = 24
PROXY_GATES = ("shopify",)

_DB_PATH = os.getenv(
    "DB_PATH",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "eagle.db"),
)

# ============ CONNECTION ============
_db: aiosqlite.Connection | None = None
_init_lock: asyncio.Lock | None = None


def _get_lock():
    global _init_lock
    if _init_lock is None:
        _init_lock = asyncio.Lock()
    return _init_lock


async def _get_db() -> aiosqlite.Connection:
    global _db
    if _db is not None:
        return _db
    async with _get_lock():
        if _db is not None:
            return _db
        conn = await aiosqlite.connect(_DB_PATH)
        conn.row_factory = aiosqlite.Row
        await conn.execute("PRAGMA journal_mode=WAL")
        await conn.execute("PRAGMA synchronous=NORMAL")
        await conn.execute("PRAGMA busy_timeout=5000")
        await conn.execute("PRAGMA foreign_keys=ON")
        await conn.commit()
        _db = conn
        return _db


# ============ HELPERS ============
def _now_iso() -> str:
    return datetime.datetime.utcnow().isoformat()


def _parse_dt(v):
    if not v:
        return None
    if isinstance(v, datetime.datetime):
        return v
    try:
        return datetime.datetime.fromisoformat(str(v))
    except Exception:
        return None


def _bool_int(v) -> int:
    return 1 if v else 0


def _norm_proxy_gate(gate: str) -> str:
    g = (gate or "shopify").strip().lower()
    return g if g in PROXY_GATES else "shopify"


# ============ INIT ============
async def init_db():
    conn = await _get_db()
    await conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            name TEXT,
            username TEXT,
            plan TEXT DEFAULT 'Trial',
            expiry TEXT,
            banned INTEGER DEFAULT 0,
            banned_by INTEGER,
            credits INTEGER DEFAULT 250,
            premium_days INTEGER DEFAULT 0,
            pending_expiry_notify INTEGER DEFAULT 0,
            plan_expiry_notified INTEGER DEFAULT 0,
            created_at TEXT,
            updated_at TEXT,
            total_checked INTEGER DEFAULT 0,
            total_charged INTEGER DEFAULT 0,
            total_approved INTEGER DEFAULT 0,
            total_declined INTEGER DEFAULT 0,
            hits INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS keys (
            key TEXT PRIMARY KEY,
            days INTEGER DEFAULT 1,
            status TEXT DEFAULT 'unused',
            assigned_to INTEGER,
            created_by INTEGER,
            created_at TEXT,
            key_expires_at TEXT,
            redeemed_by INTEGER,
            redeemed_at TEXT,
            expired_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_keys_status ON keys(status);
        CREATE INDEX IF NOT EXISTS idx_keys_expires ON keys(key_expires_at);
        CREATE INDEX IF NOT EXISTS idx_keys_assigned ON keys(assigned_to);

        CREATE TABLE IF NOT EXISTS proxies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            gate TEXT DEFAULT 'shopify',
            ip TEXT,
            port TEXT,
            username TEXT,
            password TEXT,
            proxy_url TEXT,
            proxy_type TEXT DEFAULT 'http',
            added_at TEXT
        );
        CREATE UNIQUE INDEX IF NOT EXISTS idx_proxies_user_gate_url ON proxies(user_id, gate, proxy_url);
        CREATE INDEX IF NOT EXISTS idx_proxies_user_gate ON proxies(user_id, gate);

        CREATE TABLE IF NOT EXISTS sites (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            site TEXT NOT NULL,
            added_at TEXT
        );
        CREATE UNIQUE INDEX IF NOT EXISTS idx_sites_user_site ON sites(user_id, site);

        CREATE TABLE IF NOT EXISTS global_sites (
            site TEXT PRIMARY KEY,
            added_at TEXT
        );

        CREATE TABLE IF NOT EXISTS joined_users (
            user_id INTEGER PRIMARY KEY,
            joined_at TEXT
        );

        CREATE TABLE IF NOT EXISTS feedbacks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            user_name TEXT,
            message_id INTEGER,
            chat_id INTEGER,
            media_type TEXT,
            created_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_feedbacks_user ON feedbacks(user_id);

        CREATE TABLE IF NOT EXISTS sh_sessions (
            session_id TEXT PRIMARY KEY,
            user_id INTEGER,
            total INTEGER,
            results TEXT,
            start REAL,
            name TEXT,
            view_page INTEGER DEFAULT 0,
            done INTEGER DEFAULT 0,
            stopped INTEGER DEFAULT 0,
            updated_at TEXT
        );

        CREATE TABLE IF NOT EXISTS gate_health (
            gate_key TEXT PRIMARY KEY,
            records TEXT
        );
    """)
    await conn.commit()
    print(f"✓ EAGLE SQLite DB initialized at {_DB_PATH}")


# ============ USERS ============
async def ensure_user(user_id: int, name: str = None, username: str = None):
    conn = await _get_db()
    now = _now_iso()
    await conn.execute(
        "INSERT OR IGNORE INTO users (user_id, plan, credits, banned, created_at) VALUES (?, 'Trial', 250, 0, ?)",
        (user_id, now),
    )
    sets, params = [], []
    if name:
        sets.append("name = ?")
        params.append(name)
    if username:
        sets.append("username = ?")
        params.append(username)
    if sets:
        params.append(user_id)
        await conn.execute(f"UPDATE users SET {', '.join(sets)} WHERE user_id = ?", params)
    await conn.commit()


async def check_and_expire_plan(user_id: int):
    conn = await _get_db()
    now = _now_iso()
    ph = ",".join(["?"] * len(PAID_PLANS))
    async with conn.execute(
        f"SELECT plan FROM users WHERE user_id = ? AND plan IN ({ph}) AND expiry IS NOT NULL AND expiry < ?",
        (user_id, *PAID_PLANS, now),
    ) as cur:
        row = await cur.fetchone()
    if not row:
        return None
    prev = row["plan"]
    await conn.execute(
        "UPDATE users SET plan = 'Trial', expiry = NULL, pending_expiry_notify = 1, updated_at = ? WHERE user_id = ?",
        (now, user_id),
    )
    await conn.commit()
    return prev


async def get_user_plan(user_id: int) -> str:
    if await check_and_expire_plan(user_id):
        return "Trial"
    conn = await _get_db()
    async with conn.execute("SELECT plan FROM users WHERE user_id = ?", (user_id,)) as cur:
        row = await cur.fetchone()
    if not row:
        return "Trial"
    plan = row["plan"] or "Trial"
    return "Trial" if plan == "Bronze" else plan


async def set_user_plan(user_id: int, plan: str, days: int = 0):
    conn = await _get_db()
    expiry = None
    if days > 0:
        expiry = (datetime.datetime.utcnow() + datetime.timedelta(days=days)).isoformat()
    now = _now_iso()
    await conn.execute(
        """INSERT INTO users (user_id, plan, expiry, premium_days, created_at, updated_at, pending_expiry_notify, plan_expiry_notified, credits, banned)
           VALUES (?, ?, ?, ?, ?, ?, 0, 0, 250, 0)
           ON CONFLICT(user_id) DO UPDATE SET
             plan = excluded.plan,
             expiry = excluded.expiry,
             premium_days = excluded.premium_days,
             updated_at = excluded.updated_at,
             pending_expiry_notify = 0,
             plan_expiry_notified = 0""",
        (user_id, plan, expiry, days, now, now),
    )
    await conn.commit()


async def is_premium_user(user_id: int) -> bool:
    return (await get_user_plan(user_id)) in PAID_PLANS


async def get_user_expiry(user_id: int):
    await check_and_expire_plan(user_id)
    conn = await _get_db()
    async with conn.execute("SELECT plan, expiry FROM users WHERE user_id = ?", (user_id,)) as cur:
        row = await cur.fetchone()
    if not row or row["plan"] not in PAID_PLANS:
        return None
    return _parse_dt(row["expiry"])


async def is_banned_user(user_id: int) -> bool:
    conn = await _get_db()
    async with conn.execute("SELECT banned FROM users WHERE user_id = ?", (user_id,)) as cur:
        row = await cur.fetchone()
    return bool(row["banned"]) if row else False


# ============ CREDITS ============
async def get_user_credits(user_id: int):
    conn = await _get_db()
    async with conn.execute("SELECT credits FROM users WHERE user_id = ?", (user_id,)) as cur:
        row = await cur.fetchone()
    return row["credits"] if row else 0


async def set_user_credits(user_id: int, amount: int):
    conn = await _get_db()
    await conn.execute(
        """INSERT INTO users (user_id, credits, plan, created_at) VALUES (?, ?, 'Trial', ?)
           ON CONFLICT(user_id) DO UPDATE SET credits = excluded.credits""",
        (user_id, amount, _now_iso()),
    )
    await conn.commit()


async def add_user_credits(user_id: int, amount: int):
    conn = await _get_db()
    await conn.execute(
        """INSERT INTO users (user_id, credits, plan, created_at) VALUES (?, ?, 'Trial', ?)
           ON CONFLICT(user_id) DO UPDATE SET credits = credits + ?""",
        (user_id, amount, _now_iso(), amount),
    )
    await conn.commit()


async def deduct_credit(user_id: int, amount: int = 1) -> bool:
    try:
        admin_ids = json.loads(os.getenv("ADMIN_ID", "[]"))
        if user_id in admin_ids:
            return True
    except Exception:
        pass
    if (await get_user_plan(user_id)) in PAID_PLANS:
        return True
    conn = await _get_db()
    cur = await conn.execute(
        "UPDATE users SET credits = credits - ? WHERE user_id = ? AND credits >= ?",
        (amount, user_id, amount),
    )
    changed = cur.rowcount
    await cur.close()
    await conn.commit()
    return changed > 0


async def get_user_joined_date(user_id: int):
    conn = await _get_db()
    async with conn.execute("SELECT created_at FROM users WHERE user_id = ?", (user_id,)) as cur:
        row = await cur.fetchone()
    return _parse_dt(row["created_at"]) if row else None


# ============ JOINED CACHE ============
async def mark_user_joined(user_id: int):
    conn = await _get_db()
    await conn.execute(
        """INSERT INTO joined_users (user_id, joined_at) VALUES (?, ?)
           ON CONFLICT(user_id) DO UPDATE SET joined_at = excluded.joined_at""",
        (user_id, _now_iso()),
    )
    await conn.commit()


async def is_user_marked_joined(user_id: int) -> bool:
    conn = await _get_db()
    async with conn.execute("SELECT 1 FROM joined_users WHERE user_id = ?", (user_id,)) as cur:
        row = await cur.fetchone()
    return row is not None


async def remove_joined_mark(user_id: int):
    conn = await _get_db()
    await conn.execute("DELETE FROM joined_users WHERE user_id = ?", (user_id,))
    await conn.commit()


# ============ KEYS ============
def _generate_key_code(length: int = 20) -> str:
    return KEY_PREFIX + "".join(secrets.choice(_string.ascii_letters + _string.digits) for _ in range(length))


async def create_keys(amount: int, days: int, created_by: int, assigned_to=None):
    amount = max(1, min(int(amount), MAX_KEYS_PER_GENERATE))
    days = max(1, int(days))
    now = datetime.datetime.utcnow()
    key_expires = (now + datetime.timedelta(hours=KEY_UNUSED_TTL_HOURS)).isoformat()
    conn = await _get_db()
    created = []
    for _ in range(amount):
        for _attempt in range(8):
            code = _generate_key_code()
            try:
                await conn.execute(
                    """INSERT INTO keys (key, days, status, assigned_to, created_by, created_at, key_expires_at)
                       VALUES (?, ?, 'unused', ?, ?, ?, ?)""",
                    (code, days, assigned_to, created_by, now.isoformat(), key_expires),
                )
                created.append(code)
                break
            except Exception:
                continue
    await conn.commit()
    return created


async def get_key_doc(key: str):
    if not key:
        return None
    conn = await _get_db()
    async with conn.execute("SELECT * FROM keys WHERE key = ?", (key.strip(),)) as cur:
        row = await cur.fetchone()
    return dict(row) if row else None


async def expire_stale_unused_keys() -> int:
    now = _now_iso()
    conn = await _get_db()
    cur = await conn.execute(
        "UPDATE keys SET status = 'expired', expired_at = ? WHERE status = 'unused' AND key_expires_at < ?",
        (now, now),
    )
    changed = cur.rowcount
    await cur.close()
    await conn.commit()
    return changed


async def get_remaining_keys(limit: int = 500):
    await expire_stale_unused_keys()
    now = _now_iso()
    conn = await _get_db()
    async with conn.execute(
        """SELECT key, days, assigned_to, created_at, key_expires_at FROM keys
           WHERE status = 'unused' AND key_expires_at > ? ORDER BY created_at DESC LIMIT ?""",
        (now, limit),
    ) as cur:
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


async def redeem_key(key: str, user_id: int) -> dict:
    await expire_stale_unused_keys()
    code = (key or "").strip()
    if not code:
        return {"ok": False, "error": "not_found", "days": None, "key_doc": None}
    conn = await _get_db()
    async with conn.execute("SELECT * FROM keys WHERE key = ?", (code,)) as cur:
        row = await cur.fetchone()
    if not row:
        return {"ok": False, "error": "not_found", "days": None, "key_doc": None}
    doc = dict(row)
    status = doc.get("status", "unused")
    if status == "redeemed":
        return {"ok": False, "error": "already_redeemed", "days": None, "key_doc": doc}
    if status == "expired":
        return {"ok": False, "error": "expired", "days": None, "key_doc": doc}
    now = datetime.datetime.utcnow()
    exp = _parse_dt(doc.get("key_expires_at"))
    if exp and exp < now:
        await conn.execute("UPDATE keys SET status = 'expired', expired_at = ? WHERE key = ?", (now.isoformat(), code))
        await conn.commit()
        return {"ok": False, "error": "expired", "days": None, "key_doc": doc}
    assigned = doc.get("assigned_to")
    if assigned is not None and int(assigned) != int(user_id):
        return {"ok": False, "error": "not_yours", "days": None, "key_doc": doc}
    if await is_premium_user(user_id):
        return {"ok": False, "error": "already_premium", "days": None, "key_doc": doc}
    days = int(doc.get("days") or 1)
    cur = await conn.execute(
        "UPDATE keys SET status = 'redeemed', redeemed_by = ?, redeemed_at = ? WHERE key = ? AND status = 'unused'",
        (user_id, now.isoformat(), code),
    )
    claimed = cur.rowcount
    await cur.close()
    await conn.commit()
    if claimed == 0:
        async with conn.execute("SELECT * FROM keys WHERE key = ?", (code,)) as cur2:
            fresh = await cur2.fetchone()
        if fresh:
            if fresh["status"] == "redeemed":
                return {"ok": False, "error": "already_redeemed", "days": None, "key_doc": dict(fresh)}
            if fresh["status"] == "expired":
                return {"ok": False, "error": "expired", "days": None, "key_doc": dict(fresh)}
        return {"ok": False, "error": "already_redeemed", "days": None, "key_doc": None}
    await set_user_plan(user_id, "Custom", days)
    return {"ok": True, "error": None, "days": days, "key_doc": doc}


# ============ PROXIES ============
async def add_proxy_db(user_id: int, proxy_data: dict, gate: str = "shopify"):
    gate = _norm_proxy_gate(gate)
    conn = await _get_db()
    try:
        await conn.execute(
            """INSERT OR IGNORE INTO proxies (user_id, gate, ip, port, username, password, proxy_url, proxy_type, added_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                user_id, gate,
                proxy_data.get("ip"), proxy_data.get("port"),
                proxy_data.get("username"), proxy_data.get("password"),
                proxy_data.get("proxy_url"), proxy_data.get("type", "http"),
                _now_iso(),
            ),
        )
        await conn.commit()
    except Exception:
        pass


async def get_all_user_proxies(user_id: int, gate: str = "shopify"):
    gate = _norm_proxy_gate(gate)
    conn = await _get_db()
    async with conn.execute(
        "SELECT * FROM proxies WHERE user_id = ? AND gate = ? ORDER BY added_at ASC",
        (user_id, gate),
    ) as cur:
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


async def get_proxy_count(user_id: int, gate: str = "shopify") -> int:
    gate = _norm_proxy_gate(gate)
    conn = await _get_db()
    async with conn.execute(
        "SELECT COUNT(*) AS c FROM proxies WHERE user_id = ? AND gate = ?", (user_id, gate)
    ) as cur:
        row = await cur.fetchone()
    return row["c"] if row else 0


async def get_random_proxy(user_id: int, gate: str = "shopify"):
    gate = _norm_proxy_gate(gate)
    conn = await _get_db()
    async with conn.execute(
        "SELECT * FROM proxies WHERE user_id = ? AND gate = ? ORDER BY RANDOM() LIMIT 1",
        (user_id, gate),
    ) as cur:
        row = await cur.fetchone()
    return dict(row) if row else None


async def remove_proxy_by_index(user_id: int, index: int, gate: str = "shopify"):
    proxies = await get_all_user_proxies(user_id, gate=gate)
    if 0 <= index < len(proxies):
        proxy = proxies[index]
        conn = await _get_db()
        await conn.execute("DELETE FROM proxies WHERE id = ?", (proxy["id"],))
        await conn.commit()
        return proxy
    return None


async def remove_proxy_by_url(user_id: int, proxy_url: str, gate: str = "shopify"):
    gate = _norm_proxy_gate(gate)
    conn = await _get_db()
    cur = await conn.execute(
        "DELETE FROM proxies WHERE user_id = ? AND gate = ? AND proxy_url = ?",
        (user_id, gate, proxy_url),
    )
    changed = cur.rowcount
    await cur.close()
    await conn.commit()
    return changed > 0


async def clear_all_proxies(user_id: int, gate: str = "shopify") -> int:
    gate = _norm_proxy_gate(gate)
    conn = await _get_db()
    cur = await conn.execute("DELETE FROM proxies WHERE user_id = ? AND gate = ?", (user_id, gate))
    changed = cur.rowcount
    await cur.close()
    await conn.commit()
    return changed


async def migrate_proxy_gates():
    return 0


# ============ SITES ============
async def add_site_db(user_id: int, site: str) -> bool:
    conn = await _get_db()
    try:
        await conn.execute(
            "INSERT OR IGNORE INTO sites (user_id, site, added_at) VALUES (?, ?, ?)",
            (user_id, site, _now_iso()),
        )
        await conn.commit()
        return True
    except Exception:
        return False


async def get_user_sites(user_id: int):
    conn = await _get_db()
    async with conn.execute("SELECT site FROM sites WHERE user_id = ?", (user_id,)) as cur:
        rows = await cur.fetchall()
    return [r["site"] for r in rows]


async def remove_site_db(user_id: int, site: str) -> bool:
    conn = await _get_db()
    cur = await conn.execute("DELETE FROM sites WHERE user_id = ? AND site = ?", (user_id, site))
    changed = cur.rowcount
    await cur.close()
    await conn.commit()
    return changed > 0


# ============ GLOBAL SITES ============
async def add_global_site(site: str) -> bool:
    conn = await _get_db()
    try:
        await conn.execute(
            "INSERT OR IGNORE INTO global_sites (site, added_at) VALUES (?, ?)",
            (site, _now_iso()),
        )
        await conn.commit()
        return True
    except Exception:
        return False


async def get_global_sites():
    conn = await _get_db()
    async with conn.execute("SELECT site FROM global_sites") as cur:
        rows = await cur.fetchall()
    return [r["site"] for r in rows]


async def remove_global_site(site: str) -> bool:
    conn = await _get_db()
    cur = await conn.execute("DELETE FROM global_sites WHERE site = ?", (site,))
    changed = cur.rowcount
    await cur.close()
    await conn.commit()
    return changed > 0


async def count_global_sites() -> int:
    conn = await _get_db()
    async with conn.execute("SELECT COUNT(*) AS c FROM global_sites") as cur:
        row = await cur.fetchone()
    return row["c"] if row else 0


async def add_global_sites_bulk(sites) -> int:
    conn = await _get_db()
    added = 0
    now = _now_iso()
    for site in sites:
        if not site:
            continue
        try:
            cur = await conn.execute(
                "INSERT OR IGNORE INTO global_sites (site, added_at) VALUES (?, ?)",
                (site, now),
            )
            if cur.rowcount > 0:
                added += 1
            await cur.close()
        except Exception:
            pass
    await conn.commit()
    return added


async def clear_global_sites() -> int:
    conn = await _get_db()
    cur = await conn.execute("DELETE FROM global_sites")
    changed = cur.rowcount
    await cur.close()
    await conn.commit()
    return changed


async def seed_global_sites_from_user(user_id: int) -> int:
    if await count_global_sites() > 0:
        return 0
    sites = await get_user_sites(user_id)
    if not sites:
        return 0
    return await add_global_sites_bulk(sites)


# ============ STATS ============
async def track_user_stats(user_id: int, status: str):
    if user_id is None:
        return
    s = status.upper()
    conn = await _get_db()
    await conn.execute(
        "INSERT OR IGNORE INTO users (user_id, plan, credits, banned, created_at) VALUES (?, 'Trial', 250, 0, ?)",
        (user_id, _now_iso()),
    )
    fields = {"total_checked": 1}
    if s == "CHARGED":
        fields["total_charged"] = 1
        fields["hits"] = 1
    elif s == "APPROVED":
        fields["total_approved"] = 1
    elif s == "DECLINED":
        fields["total_declined"] = 1
    sets = ", ".join(f"{k} = COALESCE({k}, 0) + ?" for k in fields.keys())
    await conn.execute(f"UPDATE users SET {sets} WHERE user_id = ?", (*fields.values(), user_id))
    await conn.commit()


async def _sum_user_field(field: str) -> int:
    conn = await _get_db()
    async with conn.execute(f"SELECT COALESCE(SUM({field}), 0) AS s FROM users") as cur:
        row = await cur.fetchone()
    return int(row["s"]) if row else 0


async def get_total_cards_count() -> int:
    return await _sum_user_field("total_checked")


async def get_charged_count() -> int:
    return await _sum_user_field("total_charged")


async def get_approved_count() -> int:
    return await _sum_user_field("total_approved")


async def get_declined_count() -> int:
    return await _sum_user_field("total_declined")


# ============ FEEDBACK ============
async def save_feedback(user_id, user_name, message_id, chat_id, media_type):
    conn = await _get_db()
    try:
        await conn.execute(
            """INSERT INTO feedbacks (user_id, user_name, message_id, chat_id, media_type, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (user_id, user_name, message_id, chat_id, media_type, _now_iso()),
        )
        await conn.commit()
    except Exception:
        pass


async def get_feedback_count() -> int:
    conn = await _get_db()
    async with conn.execute("SELECT COUNT(*) AS c FROM feedbacks") as cur:
        row = await cur.fetchone()
    return row["c"] if row else 0


# ============ BROADCAST / PREMIUM ============
async def get_total_users() -> int:
    conn = await _get_db()
    async with conn.execute("SELECT COUNT(*) AS c FROM users") as cur:
        row = await cur.fetchone()
    return row["c"] if row else 0


async def get_all_user_ids():
    conn = await _get_db()
    async with conn.execute("SELECT user_id FROM users") as cur:
        rows = await cur.fetchall()
    return [r["user_id"] for r in rows if r["user_id"]]


async def get_premium_count() -> int:
    now = _now_iso()
    ph = ",".join(["?"] * len(PAID_PLANS))
    conn = await _get_db()
    async with conn.execute(
        f"SELECT COUNT(*) AS c FROM users WHERE plan IN ({ph}) AND expiry > ?",
        (*PAID_PLANS, now),
    ) as cur:
        row = await cur.fetchone()
    return row["c"] if row else 0


async def get_all_premium_users():
    ph = ",".join(["?"] * len(PAID_PLANS))
    conn = await _get_db()
    async with conn.execute(
        f"SELECT user_id, plan, expiry FROM users WHERE plan IN ({ph})",
        tuple(PAID_PLANS),
    ) as cur:
        rows = await cur.fetchall()
    return [{"user_id": r["user_id"], "plan": r["plan"], "expiry": _parse_dt(r["expiry"])} for r in rows]


async def get_active_premium_users():
    now = _now_iso()
    ph = ",".join(["?"] * len(PAID_PLANS))
    conn = await _get_db()
    async with conn.execute(
        f"SELECT user_id, plan, expiry FROM users WHERE plan IN ({ph}) AND expiry > ?",
        (*PAID_PLANS, now),
    ) as cur:
        rows = await cur.fetchall()
    return [{"user_id": r["user_id"], "plan": r["plan"], "expiry": _parse_dt(r["expiry"])} for r in rows]


async def expire_due_plans() -> int:
    now = _now_iso()
    ph = ",".join(["?"] * len(PAID_PLANS))
    conn = await _get_db()
    cur = await conn.execute(
        f"""UPDATE users SET plan = 'Trial', expiry = NULL, pending_expiry_notify = 1, updated_at = ?
            WHERE plan IN ({ph}) AND expiry IS NOT NULL AND expiry < ?""",
        (now, *PAID_PLANS, now),
    )
    changed = cur.rowcount
    await cur.close()
    await conn.commit()
    return changed


async def get_pending_expiry_notifications(limit: int = 200):
    conn = await _get_db()
    async with conn.execute(
        "SELECT user_id FROM users WHERE pending_expiry_notify = 1 LIMIT ?", (limit,)
    ) as cur:
        rows = await cur.fetchall()
    return [{"user_id": r["user_id"]} for r in rows]


async def clear_pending_expiry_notification(user_id: int):
    conn = await _get_db()
    await conn.execute(
        "UPDATE users SET pending_expiry_notify = 0, plan_expiry_notified = 1 WHERE user_id = ?",
        (user_id,),
    )
    await conn.commit()


# ============ SITE STATS ============
async def get_total_sites_count() -> int:
    conn = await _get_db()
    async with conn.execute("SELECT COUNT(*) AS c FROM sites") as cur:
        row = await cur.fetchone()
    return row["c"] if row else 0


async def get_users_with_sites() -> int:
    conn = await _get_db()
    async with conn.execute("SELECT COUNT(DISTINCT user_id) AS c FROM sites") as cur:
        row = await cur.fetchone()
    return row["c"] if row else 0


async def get_sites_per_user():
    conn = await _get_db()
    async with conn.execute("SELECT user_id, COUNT(*) AS cnt FROM sites GROUP BY user_id") as cur:
        rows = await cur.fetchall()
    return [{"user_id": r["user_id"], "cnt": r["cnt"]} for r in rows]


async def get_all_sites_detail():
    conn = await _get_db()
    async with conn.execute("SELECT * FROM sites ORDER BY user_id") as cur:
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


# ============ HITS LEADERBOARD ============
async def get_top_hits(limit: int = 10):
    conn = await _get_db()
    async with conn.execute(
        "SELECT user_id, hits, name, username FROM users WHERE hits > 0 ORDER BY hits DESC LIMIT ?",
        (limit,),
    ) as cur:
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


async def get_total_hits() -> int:
    conn = await _get_db()
    async with conn.execute("SELECT COALESCE(SUM(hits), 0) AS s FROM users") as cur:
        row = await cur.fetchone()
    return int(row["s"]) if row else 0


async def get_user_stats(user_id: int):
    conn = await _get_db()
    async with conn.execute(
        "SELECT total_checked, total_charged, total_approved, total_declined FROM users WHERE user_id = ?",
        (user_id,),
    ) as cur:
        row = await cur.fetchone()
    if row:
        return (
            row["total_checked"] or 0,
            row["total_charged"] or 0,
            row["total_approved"] or 0,
            row["total_declined"] or 0,
        )
    return 0, 0, 0, 0


# ============ SH SESSION PERSISTENCE ============
async def save_sh_session(session: dict):
    conn = await _get_db()
    try:
        await conn.execute(
            """INSERT INTO sh_sessions (session_id, user_id, total, results, start, name, view_page, done, stopped, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(session_id) DO UPDATE SET
                 user_id = excluded.user_id,
                 total = excluded.total,
                 results = excluded.results,
                 start = excluded.start,
                 name = excluded.name,
                 view_page = excluded.view_page,
                 done = excluded.done,
                 stopped = excluded.stopped,
                 updated_at = excluded.updated_at""",
            (
                session.get("session_id"),
                session.get("user_id"),
                session.get("total"),
                json.dumps(session.get("results") or []),
                session.get("start"),
                session.get("name"),
                session.get("view_page", 0),
                _bool_int(session.get("done", False)),
                _bool_int(session.get("stopped", False)),
                _now_iso(),
            ),
        )
        await conn.commit()
    except Exception as e:
        print(f"Error saving sh session: {e}")


async def get_sh_session(session_id: str):
    conn = await _get_db()
    async with conn.execute("SELECT * FROM sh_sessions WHERE session_id = ?", (session_id,)) as cur:
        row = await cur.fetchone()
    if not row:
        return None
    d = dict(row)
    try:
        d["results"] = json.loads(d.get("results") or "[]")
    except Exception:
        d["results"] = []
    d["done"] = bool(d.get("done"))
    d["stopped"] = bool(d.get("stopped"))
    return d


# ============ GATE HEALTH ============
async def record_gate_result(gate_key: str, success: bool):
    conn = await _get_db()
    try:
        async with conn.execute("SELECT records FROM gate_health WHERE gate_key = ?", (gate_key,)) as cur:
            row = await cur.fetchone()
        records = []
        if row and row["records"]:
            try:
                records = json.loads(row["records"])
            except Exception:
                records = []
        records.append(1 if success else 0)
        records = records[-100:]
        await conn.execute(
            """INSERT INTO gate_health (gate_key, records) VALUES (?, ?)
               ON CONFLICT(gate_key) DO UPDATE SET records = excluded.records""",
            (gate_key, json.dumps(records)),
        )
        await conn.commit()
    except Exception:
        pass


async def get_gate_health(gate_key: str) -> str:
    conn = await _get_db()
    try:
        async with conn.execute("SELECT records FROM gate_health WHERE gate_key = ?", (gate_key,)) as cur:
            row = await cur.fetchone()
        if not row or not row["records"]:
            return "No Data"
        records = json.loads(row["records"])
        if not records:
            return "No Data"
        pct = int((sum(records) / len(records)) * 100)
        if pct >= 90:
            return f"{pct}%"
        elif pct >= 70:
            return f"{pct}% (Good)"
        return f"{pct}% (Degraded)"
    except Exception:
        return "No Data"
